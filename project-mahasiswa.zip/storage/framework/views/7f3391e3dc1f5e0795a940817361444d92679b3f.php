

<?php $__env->startSection('title', 'Mahasiswa-Detail'); ?>

<?php $__env->startSection('content'); ?>
<h5 style="text-align: center;" class="mt-3 mb-3">Detail Mahasiswa</h5>
<p style="text-align: center;">Data detail mahasiswa : <?php echo e($mahasiswa->name); ?></p>
<div style="text-align: center;">
    <table class="table table-bordered">
        <tr>
            <th>Name</th>
            <th>Nim</th>
            <th>Gender</th>
            <th>Alamat</th>
            <th>Fakultas</th>
            <th>Dosen</th>
            <th>Ekskul</th>
        </tr>
        <tr>
            <td><?php echo e($mahasiswa->name); ?></td>
            <td><?php echo e($mahasiswa->nim); ?></td>
            <td>
                <?php if($mahasiswa->gender == 'P'): ?>
                Perempuan
                <?php else: ?>
                Laki-laki
                <?php endif; ?>
            </td>
            <td><?php echo e($mahasiswa->alamat); ?></td>
            <td><?php echo e($mahasiswa->fakultas->name); ?></td>
            <td><?php echo e($mahasiswa->fakultas->dosen->name); ?></td>
            <td>
                <?php $__currentLoopData = $mahasiswa->ekskuls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($item->name); ?> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tr>
    </table>
</div>
<style>
th {
    width: 15%;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\application\project-mahasiswa\resources\views/mahasiswa-detail.blade.php ENDPATH**/ ?>