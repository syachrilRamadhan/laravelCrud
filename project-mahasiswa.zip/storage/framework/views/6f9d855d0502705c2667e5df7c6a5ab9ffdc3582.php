

<?php $__env->startSection('title', 'Add New Data'); ?>

<?php $__env->startSection('content'); ?>
<div class="mt-3 col-4 m-auto">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <div class="form-box">
    <form action="mahasiswa" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name">Nama</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>">
        </div>
        <div class="mb-3">
            <label for="nim">Nim</label>
            <input type="text" class="form-control" id="nim" name="nim" value="<?php echo e(old('nim')); ?>" >
        </div>
        <div class="mb-3">
            <label for="gender">Gender</label>
            <select name="gender" id="gender" class="form-control">
                <option value="">Select</option>
                <option value="P">P</option>
                <option value="L">L</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="alamat">Alamat</label>
            <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo e(old('alamat')); ?>">
        </div>
        <div class="mb-3">
            <label for="fakultas">Ekskul</label>
            <select name="fakultas_id" id="fakultas" class="form-control">
                <option value="">Select</option>
                <?php $__currentLoopData = $ekskul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="fakultas">Fakultas</label>
            <select name="fakultas_id" id="fakultas" class="form-control">
                <option value="">Select</option>
                <?php $__currentLoopData = $fakultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mt-4">
            <button class="btn btn-success" type="submit">Simpan</button>
        </div>
    </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\application\project-mahasiswa\resources\views/mahasiswa-add.blade.php ENDPATH**/ ?>