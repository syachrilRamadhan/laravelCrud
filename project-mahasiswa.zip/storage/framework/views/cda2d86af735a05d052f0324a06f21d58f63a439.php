

<?php $__env->startSection('title', 'Ekskul-Detail'); ?>

<?php $__env->startSection('content'); ?>
<h5 style="text-align: center;" class="mt-3 mb-3">Detail Ekskul</h5>
<p style="text-align: center;"><?php echo e($ekskul->name); ?></p>
<div class="mt-3" style="text-align: center;">
</div>
<div class="mt-3" style="text-align: center;">
    <table class="table table-bordered">
        <tr>
            <th>Anggota :</th>
        </tr>
        <tr>
            <td>
                <?php $__currentLoopData = $ekskul->mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($item->name); ?> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tr>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\application\project-mahasiswa\resources\views/ekskul-detail.blade.php ENDPATH**/ ?>