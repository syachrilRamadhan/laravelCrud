
<?php $__env->startSection('title', 'Fakultas-Detail'); ?>

<?php $__env->startSection('content'); ?>
<h5 style="text-align: center;" class="mt-3 mb-3">Detail Fakultas :</h5>
<p style="text-align: center;"><?php echo e($fakultas->name); ?></p>
<div class="mt-3" style="text-align: center;">
</div>
<div class="mt-3" style="text-align: center;">
    <table class="table table-bordered">
        <tr>
            <th>Dosen</th>
            <th>Mahasiswa</th>
        </tr>
        <tr>
            <td><?php echo e($fakultas->dosen->name); ?></td>
            <td>
                <?php $__currentLoopData = $fakultas->mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               - <?php echo e($item->name); ?> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tr>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\application\project-mahasiswa\resources\views/fakultas-detail.blade.php ENDPATH**/ ?>