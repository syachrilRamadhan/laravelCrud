

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?> 
<div class="mt-1">
    <h1 style="text-align: center;" class="mt-3">Hello <?php echo e(Auth::user()->name); ?></h1>
    <h3 style="text-align: center;">Selamat Datang di Sundanese University !</h3>
        <?php if(Auth::user()->role_id == 1): ?>
        <div style="align-items: center; text-align:center; justify-content:center">
        <p>Saat ini data anda sedang di proses oleh admin kami, <br>
            mohon bersabar untuk menunggu. <br>
            Selamat bergabung di Sundanese University,semoga kamu tidak <br>
            menjadi mahasiswa abadi ya !
        </p>
        <?php endif; ?>
        </div>
   
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\application\project-mahasiswa\resources\views/home.blade.php ENDPATH**/ ?>