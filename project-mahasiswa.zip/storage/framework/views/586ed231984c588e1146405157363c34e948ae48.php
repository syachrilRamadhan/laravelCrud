

<?php $__env->startSection('title', 'Edit Data Mahasiswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="mt-3 col-4 m-auto">
    <form action="/mahasiswa/<?php echo e($mahasiswa->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="name">Nama</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($mahasiswa->name); ?>" required>
        </div>
        <div class="mb-3">
            <label for="nim">Nim</label>
            <input type="text" class="form-control" id="nim" name="nim" value="<?php echo e($mahasiswa->nim); ?>" required>
        </div>
        <div class="mb-3">
            <label for="gender">Gender</label>
            <select name="gender" id="gender" class="form-control" required>
                <option value="<?php echo e($mahasiswa->gender); ?>"><?php echo e($mahasiswa->gender); ?></option>
                <?php if($mahasiswa->gender == 'L'): ?>
                <option value="P">P</option>
                <?php else: ?>
                <option value="L">L</option>
                <?php endif; ?> 
            </select>
        </div>
        <div class="mb-3">
            <label for="alamat">Alamat</label>
            <input type="text" name="alamat" id="alamat" class="form-control" value="<?php echo e($mahasiswa->alamat); ?>" required>
        </div>
        <div class="mb-3">
            <label for="fakultas">Fakultas</label>
            <select name="fakultas_id" id="fakultas" class="form-control" required>
                <option value="<?php echo e($mahasiswa->fakultas->id); ?>"><?php echo e($mahasiswa->fakultas->name); ?></option>
               <?php $__currentLoopData = $fakultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-3">
            <button class="btn btn-dark" type="submit">Update</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\application\project-mahasiswa\resources\views/mahasiswa-edit.blade.php ENDPATH**/ ?>