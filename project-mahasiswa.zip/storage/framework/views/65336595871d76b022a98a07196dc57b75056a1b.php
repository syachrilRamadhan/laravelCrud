

<?php $__env->startSection('title', 'Delete-Mahasiswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="mt-5">
    <h3 style="text-align: center;">Apakah anda yakin ingin menghapus data <?php echo e($mahasiswa->name); ?> ?</h3>
    <h5 style="text-align: center;"> Nim : <?php echo e($mahasiswa->nim); ?></h5>
    <h5 style="text-align: center;">Gender : <?php echo e($mahasiswa->gender); ?></h5>
    <h5 style="text-align: center;">Alamat : <?php echo e($mahasiswa->alamat); ?></h5>
    <h5 style="text-align: center;">Fakultas : <?php echo e($mahasiswa->fakultas->name); ?></h5>

    <form action="/mahasiswa-destroy/<?php echo e($mahasiswa->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <center><button type="submit" class="btn btn-danger">Delete</button></center>
    </form> 
    <center><a href="/mahasiswa" class="btn btn-primary mt-3">Cancel</a></center>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\application\project-mahasiswa\resources\views/mahasiswa-delete.blade.php ENDPATH**/ ?>