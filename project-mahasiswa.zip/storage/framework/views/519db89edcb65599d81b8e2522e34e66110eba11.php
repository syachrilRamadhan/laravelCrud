

<?php $__env->startSection('title', 'Dosen-Detail'); ?>

<?php $__env->startSection('content'); ?>
<h5 style="text-align: center;" class="mt-3 mb-3">Detail Dosen</h5>
<p style="text-align: center;"><?php echo e($dosen->name); ?></p>
<div class="mt-3" style="text-align: center;">
</div>
<div class="mt-3" style="text-align: center;">
    <table class="table table-bordered">
        <tr>
            <th>Fakultas :</th>
            <th>Mahasiswa :</th>
        </tr>
        <tr>
            <td>
                <?php if($dosen->fakultas): ?>
                <?php echo e($dosen->fakultas->name); ?>

                <?php else: ?>
                -
                <?php endif; ?>
            </td>
            <td>
                <?php $__currentLoopData = $dosen->fakultas->mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($data->name); ?> <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tr>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\application\project-mahasiswa\resources\views/dosen-detail.blade.php ENDPATH**/ ?>